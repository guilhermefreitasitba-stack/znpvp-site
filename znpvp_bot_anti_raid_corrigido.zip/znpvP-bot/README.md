# ZNPvP Allowlist Bot

Bot em Node.js 20+, discord.js v14 e SQLite, com painéis usando **Discord Components V2** (sem embeds tradicionais), questionário de 11 perguntas, tickets privados, revisão da staff, decisões manuais e IDs exclusivos persistidos.

## Instalação
1. Instale Node.js 20.18 ou superior.
2. Extraia o ZIP mantendo a pasta `src` e `data` no mesmo nível de `package.json`.
3. Copie `.env.example` para `.env` e confira/preencha os IDs reais e o token. Este ZIP inclui `.env.example` sem o token. Copie para `.env`, preencha `DISCORD_TOKEN` e confira os IDs. Nunca compartilhe seu `.env`.
4. No Developer Portal, ative **Server Members Intent** e **Message Content Intent** para o bot. O bot precisa de permissões para gerenciar canais, visualizar/enviar mensagens, ler histórico, gerenciar cargos e usar comandos de aplicação. O cargo do bot deve ficar acima dos cargos que ele adiciona/remove.
5. Execute `npm install`.
6. Registre o comando no servidor: `npm run deploy-commands`.
7. Inicie: `npm start`.

## Usar
- Execute `/enviar painel` com uma conta administradora ou autorizada. O painel será publicado no canal definido em `PANEL_CHANNEL_ID`.
- O candidato clica em **Iniciar Allowlist**, abre o ticket e digita `Sim`.
- O candidato responde às 11 perguntas enviando `1`, `2`, `3` ou `4` no chat.
- A solicitação final é enviada ao canal `REVIEW_CHANNEL_ID`; staff com cargo em `REVIEWER_ROLE_IDS` decide por Aprovar/Reprovar.

## Hospedagem / dados
- O banco é criado automaticamente em `data/allowlist.sqlite`. O canal de ticket é excluído 5 segundos depois da mensagem de conclusão; as respostas e a decisão permanecem salvas no SQLite e a revisão é enviada ao canal da staff.
- Use hospedagem que preserve o disco/pasta `data` em reinicializações e redeploys. Em containers efêmeros, monte um volume persistente nesse diretório; sem isso, o SQLite local pode ser perdido.
- `better-sqlite3` é um módulo nativo. Em hospedagens Linux, use imagem/ambiente Node compatível e deixe `npm install` compilar/instalar a dependência.
- Não publique o `.env` nem envie o token a terceiros.

## IDs exclusivos
A atribuição começa em `ID_START` (1238) e procura IDs livres até `ID_INITIAL_MAX` (8000). Depois amplia até `ID_HARD_MAX` (30000). A tabela `player_ids` possui chave primária no ID e índice único no Discord ID; a atribuição é transacional.

## Personalização
Textos, IDs, cores, imagem e cargos ficam no `.env`. As perguntas e alternativas ficam em `src/questions.js`, pois JSON com textos longos e quebras de linha no `.env` é pouco prático e sujeito a erros. Não é necessário alterar o código principal para personalizar as perguntas: basta editar esse arquivo e reiniciar.

## Observações importantes
- O Discord limita tamanho total de componentes e de mensagens. O painel de revisão divide as perguntas em blocos de texto separados.
- A aprovação é manual; a propriedade `correct` nas perguntas é apenas referência para a equipe e não aprova/reprova automaticamente.
- O bot tenta enviar DM, mas não pode garantir entrega se o candidato bloquear mensagens privadas.
- Faça backup periódico de `data/allowlist.sqlite`.


## Aprovação, cargos, apelido e cores
- Ao aprovar, o bot atribui um ID aleatório e exclusivo entre 1239 e 8000; quando essa faixa acabar, usa IDs aleatórios entre 8001 e 30000. IDs já atribuídos nunca são reutilizados.
- O apelido fica no formato `ID | Nome de exibição atual`, respeitando o limite de 32 caracteres do Discord.
- `REMOVE_ROLE_ID` aceita um ou mais IDs reais de cargos separados por vírgula. O valor precisa ser o ID numérico do cargo, não um texto de exemplo. O cargo do bot precisa estar acima dos cargos que serão removidos/adicionados e o bot precisa da permissão **Gerenciar cargos**.
- `CONTAINER_COLOR=FF0000` define vermelho para todos os containers Components V2 que usam cor de destaque.

## Indicador roxo do Discord
A atividade **Streaming/Transmitindo** é configurada no evento de inicialização e reaplicada quando o shard retoma a conexão. O status de disponibilidade (`online`, bolinha verde) é separado da atividade. O `.env` deste projeto já define `BOT_ACTIVITY_TYPE=Streaming` e a URL enviada. Links curtos `youtu.be` são normalizados para o formato canônico `youtube.com/watch?v=...`, preservando o mesmo ID do vídeo. O Discord pode não exibir o indicador roxo para um vídeo comum que não seja uma transmissão ao vivo; para garantir compatibilidade, use a URL real de uma live/canal do YouTube ou de uma transmissão Twitch. Nenhuma URL alternativa é inventada.

## Painel de conexão ZNPvP
- Configure `CONNECT_IMAGE_URL` com o link direto da imagem que aparecerá no topo.
- Configure `CONNECT_BUTTON_URL` com o link que o botão **ENTRAR ZNPvP** deve abrir.
- Personalize `CONNECT_CODE` com o código que será exibido em bloco de código.
- Use `/enviar_conecte` para publicar o painel no canal em que o comando for executado. O comando é restrito aos administradores autorizados, como os demais comandos administrativos.
- O painel usa Discord Components V2 e não altera os outros sistemas do bot.


## Convite (adicionado)
- Configure `INVITES_CHANNEL_ID` no `.env` com o ID do canal onde serão publicadas as entradas.
- O bot registra quem convidou, quem entrou e o total acumulado de convites por pessoa, usando o SQLite existente em `data/allowlist.sqlite`.
- Não há consulta periódica: o sistema mantém um snapshot em memória e compara os usos quando alguém entra.
- O bot precisa da permissão **Gerenciar servidor** para consultar os convites, além de poder visualizar e enviar mensagens no canal de registro.
- Convites personalizados, usos simultâneos, convites temporários e entradas por URL personalizada/vanity podem impedir a identificação exata em alguns casos; quando não for possível identificar o autor com segurança, o bot não atribui o convite.


## Permanência em call e hospedagem 24/7
O bot agora verifica a conexão de voz a cada 15 segundos, tenta reconectar após desconexões e evita acumular vários temporizadores de reconexão. Isso recupera quedas de voz enquanto o processo Node estiver em execução.
**Nenhum código consegue reconectar se a hospedagem suspender ou encerrar o processo.** Para ficar 24/7 no Replit, use uma implantação sempre ativa compatível com processos contínuos (por exemplo, uma Reserved VM, se disponível no seu plano) e confira os logs. Não use um ping artificial para contornar suspensão do plano.


## Sistema Armadilha Anti Raid
- Configure `ANTI_RAID_CHANNEL_ID` no `.env` com o ID do canal dedicado à armadilha.
- Use `/enviar_armadilha` para publicar o painel vermelho sem emojis. O contador mostra o total de banimentos e atualiza a cada 2 minutos.
- Mensagens de membros comuns nesse canal causam banimento permanente; administradores autorizados, revisores e bots são ignorados para evitar acidentes. A DM pode falhar se o usuário bloquear mensagens privadas.
- O bot precisa de **Banir membros**, **Gerenciar mensagens** e acesso ao canal. A posição do cargo do bot também deve permitir banir os membros-alvo.
