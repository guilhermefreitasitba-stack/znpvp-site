require('dotenv').config();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const cfg = require('./config');
const commands = [
  new SlashCommandBuilder().setName('enviar').setDescription('Enviar painel de Allowlist').addSubcommand(s => s.setName('painel').setDescription('Envia o painel de Allowlist ZNPvP')).setDMPermission(false).toJSON(),
  new SlashCommandBuilder().setName('enviar_conecte').setDescription('Envia o painel para conectar no servidor ZNPvP').setDMPermission(false).toJSON(),
  new SlashCommandBuilder().setName('enviar_armadilha').setDescription('Envia o painel do Sistema Armadilha Anti Raid').setDMPermission(false).toJSON()
];
(async()=>{ const rest = new REST({version:'10'}).setToken(cfg.token); await rest.put(Routes.applicationGuildCommands(cfg.clientId,cfg.guildId),{body:commands}); console.log('Comandos /enviar painel e /enviar_conecte registrados.'); })().catch(e=>{console.error('Falha ao registrar comandos:',e.message);process.exit(1);});
