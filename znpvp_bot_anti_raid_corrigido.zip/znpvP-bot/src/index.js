const { Client, GatewayIntentBits, ChannelType, PermissionFlagsBits, MessageFlags, Events, ActivityType, REST, Routes, SlashCommandBuilder } = require('discord.js');
const cfg = require('./config');
const db = require('./db');
const questions = require('./questions');
const { container, panelContainer, connectContainer, questionContainer, reviewContainer, reviewDetailContainers, flags } = require('./ui');
const { ContainerBuilder, TextDisplayBuilder, SectionBuilder, ButtonBuilder, ButtonStyle, SeparatorBuilder } = require('discord.js');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
// Sistema independente de convites. Mantém apenas o snapshot necessário em memória;
// totais e entradas ficam persistidos no SQLite.
const inviteCache = new Map();
const getInviteSnapshot = async guild => {
  const invites = await guild.invites.fetch();
  return new Map(invites.map(invite => [invite.code, { uses: invite.uses ?? 0, inviterId: invite.inviter?.id ?? null }]));
};
const saveInviteSnapshot = async guild => {
  try { inviteCache.set(guild.id, await getInviteSnapshot(guild)); }
  catch (e) { console.warn(`[CONVITES] Não foi possível ler os convites de ${guild.name}; confira a permissão Gerenciar servidor: ${e.message}`); }
};
const findUsedInvite = (previous, current) => {
  for (const [code, invite] of current) {
    const old = previous?.get(code);
    if (invite.uses > (old?.uses ?? 0)) return { code, inviterId: invite.inviterId };
  }
  return null;
};
const recordInviteJoin = db.prepare('INSERT OR IGNORE INTO invite_joins (guild_id, invited_user_id, inviter_id, invite_code, joined_at) VALUES (?,?,?,?,?)');
const incrementInviteCount = db.prepare(`INSERT INTO invite_stats (inviter_id, invite_count) VALUES (?,1)
  ON CONFLICT(inviter_id) DO UPDATE SET invite_count = invite_count + 1`);
const getInviteCount = db.prepare('SELECT invite_count FROM invite_stats WHERE inviter_id=?');

const now = () => new Date().toISOString();
const activeForUser = db.prepare("SELECT * FROM applications WHERE user_id=? AND status IN ('awaiting_start','in_progress','pending') ORDER BY id DESC LIMIT 1");
const cancelStaleApp = db.prepare("UPDATE applications SET status='cancelled' WHERE id=? AND status IN ('awaiting_start','in_progress','pending')");
const byId = db.prepare('SELECT * FROM applications WHERE id=?');
const saveApp = db.prepare("INSERT INTO applications (user_id,guild_id,ticket_channel_id,status,question_index,answers_json,created_at,display_name) VALUES (?,?,?,'awaiting_start',0,?,?,?)");
const setApp = db.prepare('UPDATE applications SET ticket_channel_id=?, status=?, question_index=?, answers_json=? WHERE id=?');
const updateStatus = db.prepare('UPDATE applications SET status=?, decided_at=?, decided_by=?, decision_reason=?, exclusive_id=? WHERE id=? AND status=\'pending\'');
const idExists = db.prepare('SELECT 1 FROM player_ids WHERE exclusive_id=?');
function randomFreeId(min, max) {
  const count = max - min + 1;
  if (count <= 0) return null;
  // Tenta amostras aleatórias primeiro; depois varre o intervalo para garantir
  // que não falhe apenas porque as tentativas aleatórias repetiram números.
  for (let attempt=0; attempt<Math.min(500, count * 2); attempt++) {
    const candidate = min + Math.floor(Math.random() * count);
    if (!idExists.get(candidate)) return candidate;
  }
  const start = Math.floor(Math.random() * count);
  for (let offset=0; offset<count; offset++) {
    const candidate = min + ((start + offset) % count);
    if (!idExists.get(candidate)) return candidate;
  }
  return null;
}
const allocateId = (app, user, displayName) => {
  const existing = db.prepare('SELECT exclusive_id FROM player_ids WHERE user_id=?').get(user.id);
  if (existing) return existing.exclusive_id;
  // A primeira faixa começa estritamente acima de 1238; só quando ela acabar
  // a atribuição passa para a faixa estendida, até 30000.
  const firstMin = Math.max(1239, cfg.idStart + 1);
  let id = randomFreeId(firstMin, cfg.idInitialMax);
  if (id === null) id = randomFreeId(cfg.idInitialMax + 1, cfg.idHardMax);
  if (id === null) throw new Error(`IDs de Allowlist esgotados até ${cfg.idHardMax}`);
  db.prepare('INSERT INTO player_ids (exclusive_id,user_id,display_name,assigned_at,application_id) VALUES (?,?,?,?,?)').run(id,user.id,displayName,now(),app.id);
  console.log(`[ID] ID ${id} reservado no SQLite para Discord ${user.id}, allowlist #${app.id}.`);
  return id;
};
function isAdmin(member) {
  if (!member) return false;
  if (cfg.adminUserIds.includes(member.id)) return true;
  if (member.permissions?.has(PermissionFlagsBits.Administrator)) return true;
  return cfg.adminRoleIds.some(id => member.roles?.cache?.has(id));
}
function isReviewer(member) { return isAdmin(member) || cfg.reviewerRoleIds.some(id => member.roles?.cache?.has(id)); }
function safeChannelName(name) {
  const clean = name.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'').slice(0,85);
  return `allowlist-${clean || 'candidato'}`.slice(0,95);
}
async function log(guild, text) {
  try { const ch = await guild.channels.fetch(cfg.logChannelId); if (ch?.isTextBased()) await ch.send({ components:[container('Log de Allowlist',text)], flags }); } catch (e) { console.error('Falha ao enviar log:',e.message); }
}
async function sendReview(app) {
  const channel = await client.channels.fetch(cfg.reviewChannelId);
  const fresh = byId.get(app.id);
  const message = await channel.send({ components:[reviewContainer(fresh,questions)], flags });
  db.prepare('UPDATE applications SET review_message_id=? WHERE id=?').run(message.id,app.id);
  for (const detail of reviewDetailContainers(fresh,questions)) await channel.send({ components:[detail], flags });
}
async function sendQuestion(channel, index) {
  await channel.send({ components:[questionContainer(index,questions[index])], flags });
}
async function finishApplication(app, channel) {
  // A validação do canal vem do registro exato da aplicação, para nunca fechar
  // um canal que não seja o ticket associado a esta allowlist.
  const changed = db.prepare("UPDATE applications SET status='pending' WHERE id=? AND status='in_progress' AND ticket_channel_id=? AND guild_id=?")
    .run(app.id, channel.id, channel.guildId);
  if (!changed.changes) return; // Evita envio duplicado e timers repetidos.

  await channel.send({ components:[container(cfg.submissionTitle,cfg.submissionDescription)], flags });
  await channel.send({
    components:[container('Atendimento concluído','Sua Allowlist foi enviada para análise. Este ticket será fechado automaticamente em **5 segundos**. Você receberá o resultado por mensagem privada.')],
    flags
  });

  // O fechamento é a exclusão do canal do ticket, 5 segundos depois da mensagem.
  // A solicitação e as respostas permanecem no SQLite e a revisão fica no canal da staff.
  setTimeout(async () => {
    try {
      const currentApp = byId.get(app.id);
      if (!currentApp || currentApp.status !== 'pending' ||
          currentApp.ticket_channel_id !== channel.id || currentApp.guild_id !== channel.guildId) {
        console.warn(`[TICKET] Fechamento cancelado: o canal ${channel.id} não corresponde mais à allowlist #${app.id}.`);
        return;
      }
      const ticket = await client.channels.fetch(channel.id).catch(() => null);
      if (!ticket || ticket.type !== ChannelType.GuildText || ticket.guildId !== app.guild_id) {
        console.warn(`[TICKET] Canal ${channel.id} já não existe ou não é um canal de texto do servidor da allowlist #${app.id}.`);
        return;
      }
      await ticket.delete(`Allowlist #${app.id} concluída; fechamento automático após 5 segundos`);
      console.log(`[TICKET] Canal ${channel.id} excluído 5 segundos após a conclusão da allowlist #${app.id}. Respostas preservadas no banco.`);
    } catch (e) {
      console.error(`[TICKET] Falha ao fechar/excluir o ticket ${channel.id} da allowlist #${app.id}: ${e.message}`);
    }
  }, 5000);

  const fresh = byId.get(app.id);
  try {
    await sendReview(fresh);
    await log(channel.guild, `Solicitação #${app.id} enviada para análise. Candidato: <@${app.user_id}> (\`${app.user_id}\`).`);
  } catch (e) {
    console.error(`[ALLOWLIST] Falha ao encaminhar a solicitação #${app.id} para revisão:`, e.stack || e.message);
    await channel.send({ components:[container('Aviso','Não consegui encaminhar automaticamente à staff. Avise um administrador; suas respostas continuam salvas.')], flags }).catch(err => console.error('[ALLOWLIST] Não consegui enviar aviso no ticket:', err.message));
  }
}

async function applyConfiguredPresence(c) {
  const activityText = process.env.BOT_ACTIVITY_TEXT || 'ZNPvP';
  const requestedActivity = process.env.BOT_ACTIVITY_TYPE || 'Listening';
  const activityNames = {
    Playing: ActivityType.Playing,
    Streaming: ActivityType.Streaming,
    Listening: ActivityType.Listening,
    Watching: ActivityType.Watching,
    Competing: ActivityType.Competing
  };
  const activityType = activityNames[requestedActivity] ?? ActivityType.Listening;
  let activityUrl = (process.env.BOT_ACTIVITY_URL || '').trim();

  // Discord expects a Twitch/YouTube stream URL. Normalize the supplied YouTube
  // short link to its canonical watch URL without changing the video ID.
  const shortYoutube = activityUrl.match(/^https?:\/\/(?:www\.)?youtu\.be\/([A-Za-z0-9_-]{11})(?:[?#].*)?$/i);
  if (shortYoutube) activityUrl = `https://www.youtube.com/watch?v=${shortYoutube[1]}`;

  const validStreamingUrl = /^https?:\/\/(?:www\.)?(?:twitch\.tv\/[^/?#]+|youtube\.com\/(?:watch\?v=[A-Za-z0-9_-]{6,}|live\/[^/?#]+))(?:[&#?].*)?$/i.test(activityUrl);
  if (activityType === ActivityType.Streaming && !validStreamingUrl) {
    console.error('Presença Streaming não aplicada: BOT_ACTIVITY_URL precisa ser uma URL válida de stream do Twitch ou YouTube.');
    return;
  }

  const activity = {
    name: activityText,
    type: activityType,
    ...(activityType === ActivityType.Streaming ? { url: activityUrl } : {})
  };

  try {
    await c.user.setPresence({ status: 'online', activities: [activity] });
    console.log(`Presença aplicada: ${requestedActivity} | ${activityText}${activityType === ActivityType.Streaming ? ` | ${activityUrl}` : ''}`);
  } catch (e) {
    console.error('Não foi possível aplicar a presença do bot:', e?.message || e);
  }
}


const antiRaidCount = db.prepare('SELECT COUNT(*) AS total FROM anti_raid_bans WHERE guild_id=?');
const saveAntiRaidBan = db.prepare('INSERT OR IGNORE INTO anti_raid_bans (guild_id,user_id,created_at) VALUES (?,?,?)');
let antiRaidPanelMessage = null;
function antiRaidPanel(total) {
  const c = new ContainerBuilder().setAccentColor(0xFF0000);
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent('# Sistema Armadilha ZNPvP'));
  c.addSeparatorComponents(new SeparatorBuilder());
  c.addSectionComponents(section => section
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      '**NÃO ENVIE MENSAGENS NESTE CANAL.**\n\n' +
      'Este canal é exclusivo do Sistema Armadilha da ZNPvP e não deve ser utilizado para conversas, testes ou qualquer outro tipo de mensagem.\n\n' +
      '**Qualquer mensagem enviada aqui poderá resultar em banimento permanente do servidor.**\n\n' +
      'Este sistema foi criado para ajudar a combater raids e atividades de contas comprometidas ou hackeadas. Ao enviar uma mensagem neste canal, você estará sujeito à aplicação automática das medidas de segurança.\n\n' +
      'A equipe da ZNPvP não se responsabiliza por mensagens enviadas neste canal. Se você acredita que foi banido por engano, entre em contato por mensagem privada com **Zeus Nexor** para solicitar uma revisão.'
    ))
    .setButtonAccessory(new ButtonBuilder().setCustomId('anti_raid:count').setLabel(`${total}/${total}`).setStyle(ButtonStyle.Secondary).setDisabled(true))
  );
  return c;
}
async function refreshAntiRaidPanel() {
  if (!cfg.antiRaidChannelId || !antiRaidPanelMessage) return;
  try {
    const total = antiRaidCount.get(antiRaidPanelMessage.guildId).total;
    await antiRaidPanelMessage.edit({ components: [antiRaidPanel(total)], flags });
  } catch (e) { console.warn(`[ANTI RAID] Não foi possível atualizar o painel: ${e.message}`); }
}
client.on(Events.MessageCreate, async message => {
  if (!cfg.antiRaidChannelId || message.channelId !== cfg.antiRaidChannelId || !message.guild || message.author.bot) return;
  // Evita banimentos acidentais de administradores e equipe autorizada.
  if (isAdmin(message.member) || cfg.reviewerRoleIds.some(id => message.member?.roles?.cache?.has(id))) return;
  try {
    // Apaga a mensagem antes do banimento e registra claramente qualquer falha de permissão.
    try {
      await message.delete();
      console.log(`[ANTI RAID] Mensagem de ${message.author.tag} apagada no canal ${message.channelId}.`);
    } catch (deleteError) {
      console.error(`[ANTI RAID] NÃO foi possível apagar a mensagem de ${message.author.tag}. Confira a permissão Gerenciar mensagens no canal: ${deleteError.message}`);
    }
    const already = db.prepare('SELECT 1 FROM anti_raid_bans WHERE guild_id=? AND user_id=?').get(message.guild.id, message.author.id);
    await message.guild.members.ban(message.author.id, { reason: 'Sistema Armadilha ZNPvP: mensagem enviada no canal Anti Raid.' });
    if (!already) saveAntiRaidBan.run(message.guild.id, message.author.id, new Date().toISOString());
    try {
      await message.author.send('Você foi banido da ZNPvP. Se acha que seu banimento foi incorreto, mande uma mensagem na DM do Zeus Nexor. Sistema de proteção contra contas hackeadas e raids.');
    } catch { /* A DM pode estar bloqueada pelo usuário. */ }
    await refreshAntiRaidPanel();
    console.log(`[ANTI RAID] Banimento de ${message.author.tag} (${message.author.id}) em ${message.guild.name}.`);
  } catch (e) {
    console.error(`[ANTI RAID] Falha ao banir ${message.author.tag}: ${e.message}`);
  }
});

client.once(Events.ClientReady, async c => {
  // Aplica a presença antes de qualquer tarefa de rede do startup.
  await applyConfiguredPresence(c);

  // Snapshot inicial para comparar usos sem polling contínuo.
  for (const guild of c.guilds.cache.values()) await saveInviteSnapshot(guild);

  // Registra/atualiza os comandos deste servidor automaticamente ao iniciar.
  // Assim não depende de executar manualmente `npm run deploy-commands`.
  try {
    const commands = [
      new SlashCommandBuilder()
        .setName('enviar')
        .setDescription('Enviar painel de Allowlist')
        .addSubcommand(sub => sub.setName('painel').setDescription('Envia o painel de Allowlist ZNPvP'))
        .setDMPermission(false)
        .toJSON(),
      new SlashCommandBuilder()
        .setName('enviar_conecte')
        .setDescription('Envia o painel para conectar no servidor ZNPvP')
        .setDMPermission(false)
        .toJSON(),
      new SlashCommandBuilder()
        .setName('enviar_armadilha')
        .setDescription('Envia o painel do Sistema Armadilha Anti Raid')
        .setDMPermission(false)
        .toJSON()
    ];
    const rest = new REST({ version: '10' }).setToken(cfg.token);
    await rest.put(Routes.applicationGuildCommands(cfg.clientId, cfg.guildId), { body: commands });
    console.log('Comandos slash registrados/atualizados no servidor configurado.');
  } catch (e) {
    console.error('Não foi possível registrar os comandos slash automaticamente:', e.message);
    console.error('Confira CLIENT_ID, GUILD_ID e se o bot foi convidado com o escopo applications.commands.');
  }
  if (cfg.antiRaidChannelId) {
    try {
      const channel = await c.channels.fetch(cfg.antiRaidChannelId);
      if (channel?.isTextBased()) {
        const recent = await channel.messages.fetch({ limit: 30 });
        antiRaidPanelMessage = recent.find(m => m.author.id === c.user.id && m.components?.length && m.components.some(row => row.components?.some(comp => comp.customId === 'anti_raid:count'))) || null;
        if (antiRaidPanelMessage) await refreshAntiRaidPanel();
        setInterval(refreshAntiRaidPanel, 120000);
      }
    } catch (e) { console.warn(`[ANTI RAID] Não foi possível localizar o painel: ${e.message}`); }
  }

});
client.on(Events.GuildCreate, guild => { saveInviteSnapshot(guild); });

client.on(Events.GuildMemberAdd, async member => {
  if (!cfg.inviteLogChannelId) return;
  const guild = member.guild;
  const previous = inviteCache.get(guild.id);
  let current;
  try {
    current = await getInviteSnapshot(guild);
    inviteCache.set(guild.id, current);
  } catch (e) {
    console.warn(`[CONVITES] Falha ao identificar convite usado em ${guild.name}: ${e.message}`);
    return;
  }
  const used = findUsedInvite(previous, current);
  if (!used?.inviterId || used.inviterId === member.id) return;

  // A chave única evita contar duas vezes a mesma entrada em caso de evento repetido.
  const transaction = db.transaction(() => {
    const result = recordInviteJoin.run(guild.id, member.id, used.inviterId, used.code, now());
    if (result.changes) incrementInviteCount.run(used.inviterId);
    return result.changes > 0;
  });
  if (!transaction()) return;

  const total = getInviteCount.get(used.inviterId)?.invite_count ?? 1;
  try {
    const channel = await guild.channels.fetch(cfg.inviteLogChannelId);
    if (!channel?.isTextBased()) {
      console.warn(`[CONVITES] INVITES_CHANNEL_ID (${cfg.inviteLogChannelId}) não é um canal de texto acessível.`);
      return;
    }
    await channel.send({
      components: [container('Convite',
        `**Novo membro convidado!**\n\n**Quem convidou:** <@${used.inviterId}>\n**Quem entrou:** <@${member.id}>\n**Total de convites:** **${total}**`)],
      flags,
      allowedMentions: { users: [used.inviterId, member.id] }
    });
  } catch (e) {
    console.error(`[CONVITES] Não foi possível enviar o registro de entrada: ${e.message}`);
  }
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand() && interaction.commandName === 'enviar_armadilha') {
      if (!isAdmin(interaction.member)) return interaction.reply({ components:[container('Sem permissão','Somente administradores autorizados podem usar este comando.')], flags, ephemeral:true });
      if (!cfg.antiRaidChannelId) return interaction.reply({ components:[container('Configuração incompleta','Defina ANTI_RAID_CHANNEL_ID no arquivo .env com o ID do canal de armadilha.')], flags, ephemeral:true });
      const channel = await interaction.guild.channels.fetch(cfg.antiRaidChannelId);
      if (!channel?.isTextBased()) return interaction.reply({ components:[container('Canal inválido','O ID em ANTI_RAID_CHANNEL_ID não corresponde a um canal de texto.')], flags, ephemeral:true });
      const total = antiRaidCount.get(interaction.guild.id).total;
      antiRaidPanelMessage = await channel.send({ components:[antiRaidPanel(total)], flags });
      setInterval(refreshAntiRaidPanel, 120000);
      return interaction.reply({ components:[container('Painel enviado',`O Sistema Armadilha foi enviado em <#${channel.id}>.`)], flags, ephemeral:true });
    }
    if (interaction.isChatInputCommand() && interaction.commandName === 'enviar_conecte') {
      if (!isAdmin(interaction.member)) return interaction.reply({ components:[container('Sem permissão','Somente administradores autorizados podem usar este comando.')], flags, ephemeral:true });
      if (!cfg.connectImageUrl || !/^https?:\/\//i.test(cfg.connectImageUrl)) {
        return interaction.reply({ components:[container('Configuração incompleta','Defina CONNECT_IMAGE_URL no arquivo .env antes de enviar o painel.')], flags, ephemeral:true });
      }
      if (!cfg.connectButtonUrl || !/^https?:\/\//i.test(cfg.connectButtonUrl)) {
        return interaction.reply({ components:[container('Configuração incompleta','Defina CONNECT_BUTTON_URL no arquivo .env antes de enviar o painel.')], flags, ephemeral:true });
      }
      const channel = await interaction.guild.channels.fetch(interaction.channelId);
      await channel.send({ components:[connectContainer(cfg)], flags });
      return interaction.reply({ components:[container('Painel enviado',`O painel de conexão ZNPvP foi enviado em <#${channel.id}>.`)], flags, ephemeral:true });
    }
    if (interaction.isChatInputCommand() && interaction.commandName === 'enviar') {
      if (interaction.options.getSubcommand() !== 'painel') return;
      if (!isAdmin(interaction.member)) return interaction.reply({ components:[container('Sem permissão','Somente administradores autorizados podem usar este comando.')], flags, ephemeral:true });
      const channel = await client.channels.fetch(cfg.panelChannelId);
      await channel.send({ components:[panelContainer(cfg)], flags });
      return interaction.reply({ components:[container('Painel enviado',`O painel foi enviado em <#${cfg.panelChannelId}>.`)], flags, ephemeral:true });
    }
    if (!interaction.isButton()) return;
    if (interaction.customId === 'anti_raid:count') return interaction.deferUpdate();
    if (interaction.customId === 'allowlist:start') {
      let active = activeForUser.get(interaction.user.id);
      if (active) {
        // Se o ticket foi apagado manualmente, não bloqueie o candidato com uma solicitação fantasma.
        let activeChannel = null;
        if (active.ticket_channel_id) activeChannel = await client.channels.fetch(active.ticket_channel_id).catch(() => null);
        if (!activeChannel || activeChannel.isDMBased?.()) {
          cancelStaleApp.run(active.id);
          console.warn(`Solicitação antiga #${active.id} marcada como cancelada: canal ${active.ticket_channel_id || '(sem canal)'} não existe mais.`);
          active = null;
        }
      }
      if (active) return interaction.reply({ components:[container('Allowlist em andamento',`Você já possui uma solicitação em andamento: <#${active.ticket_channel_id}>.`)], flags, ephemeral:true });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
      const guild = interaction.guild;
      const overwrites = [
        { id:guild.roles.everyone.id, deny:[PermissionFlagsBits.ViewChannel] },
        { id:interaction.user.id, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory] },
        { id:client.user.id, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.ManageMessages] }
      ];
      for (const roleId of cfg.reviewerRoleIds) overwrites.push({id:roleId,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]});
      const channel = await guild.channels.create({ name:safeChannelName(interaction.member?.displayName || interaction.user.globalName || interaction.user.username), type:ChannelType.GuildText, parent:cfg.ticketCategoryId, permissionOverwrites:overwrites, reason:`Allowlist de ${interaction.user.id}` });
      let appId;
      try { appId = saveApp.run(interaction.user.id,guild.id,channel.id,'[]',now(),interaction.member?.displayName || interaction.user.globalName || interaction.user.username).lastInsertRowid; }
      catch (e) { await channel.delete().catch(()=>{}); throw e; }
      await channel.send({ components:[container(cfg.welcomeTitle,`<@${interaction.user.id}>\n\n${cfg.welcomeDescription}`)], flags, allowedMentions:{users:[interaction.user.id]} });
      return interaction.editReply({ components:[container('Ticket criado',`Sua Allowlist foi aberta em <#${channel.id}>. Digite **Sim** para começar.`)], flags });
    }
    const parts = interaction.customId.split(':');
    if (parts[1] === 'approve' || parts[1] === 'reject') {
      if (!isReviewer(interaction.member)) return interaction.reply({ components:[container('Sem permissão','Você não possui um cargo autorizado para analisar Allowlist.')], flags, ephemeral:true });
      const appId = Number(parts[2]);
      const app = byId.get(appId);
      if (!app || app.status !== 'pending') return interaction.reply({ components:[container('Solicitação já decidida','Esta solicitação não está mais pendente.')], flags, ephemeral:true });
      await interaction.deferReply({ flags:MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
      const decision = parts[1] === 'approve' ? 'approved' : 'rejected';
      let exclusiveId = null;
      const user = await client.users.fetch(app.user_id).catch(()=>null);
      const guild = interaction.guild;
      const member = await guild.members.fetch(app.user_id).catch(()=>null);
      const displayName = member?.displayName || user?.globalName || user?.username || app.display_name;
      const transaction = db.transaction(() => {
        const current = byId.get(appId);
        if (!current || current.status !== 'pending') throw new Error('Esta solicitação já foi decidida por outra pessoa.');
        if (decision === 'approved') exclusiveId = allocateId(current,user || {id:app.user_id},displayName);
        const changed = updateStatus.run(decision,now(),interaction.user.id,null,exclusiveId,appId);
        if (!changed.changes) throw new Error('Esta solicitação já foi decidida por outra pessoa.');
        db.prepare('INSERT INTO decisions (application_id,user_id,decision,staff_id,created_at,exclusive_id) VALUES (?,?,?,?,?,?)').run(appId,app.user_id,decision,interaction.user.id,now(),exclusiveId);
      });
      try { transaction(); } catch(e) { return interaction.editReply({ components:[container('Não foi possível decidir',e.message)], flags }); }
      const finalApp = byId.get(appId);
      const original = await interaction.channel.messages.fetch(app.review_message_id).catch(()=>null);
      if (original) await original.edit({ components:[reviewContainer(finalApp,questions,decision === 'approved' ? `APROVADA por <@${interaction.user.id}> • ID ${exclusiveId}` : `REPROVADA por <@${interaction.user.id}>`)], flags }).catch(e=>console.error('Não atualizei painel:',e.message));
      if (decision === 'approved') {
        // Busca o membro novamente; o primeiro fetch pode falhar ou estar desatualizado.
        const freshMember = await guild.members.fetch({ user: app.user_id, force: true }).catch(e => {
          console.error(`[APROVACAO] Não consegui buscar o membro ${app.user_id}:`, e.message);
          return null;
        });
        if (!freshMember) {
          console.error(`[APROVACAO] ID ${exclusiveId} reservado, mas cargos/apelido não aplicados: membro não encontrado no servidor.`);
        } else {
          const botMember = guild.members.me || await guild.members.fetch(client.user.id).catch(() => null);
          if (!botMember) {
            console.error(`[CARGOS] Não consegui carregar o membro do bot no servidor ${guild.id}; nenhum cargo será alterado.`);
          } else if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
            console.error(`[CARGOS] O bot não tem a permissão Gerenciar cargos no servidor ${guild.id}; nenhum cargo será alterado.`);
          } else {
            const configuredRemoveIds = cfg.removeRoleIds;
            if (!configuredRemoveIds.length) {
              console.error('[CONFIG] REMOVE_ROLE_ID está vazio. Nenhum cargo de entrada será removido; configure um ou mais IDs separados por vírgula.');
            }
            const validRemoveRoleIds = configuredRemoveIds.filter(id => /^\d{17,20}$/.test(id));
            for (const invalidId of configuredRemoveIds.filter(id => !/^\d{17,20}$/.test(id))) {
              console.error(`[CONFIG] REMOVE_ROLE_ID inválido ("${invalidId}"). Informe o ID numérico do cargo.`);
            }
            const roleIdsToChange = [...new Set([...validRemoveRoleIds, cfg.approvedRoleId].filter(id => /^\d{17,20}$/.test(id)))];
            const roleObjects = new Map();
            for (const roleId of roleIdsToChange) {
              const role = await guild.roles.fetch(roleId).catch(e => {
                console.error(`[CARGOS] Não consegui buscar o cargo ${roleId} no servidor ${guild.id}: ${e.message}`);
                return null;
              });
              if (!role) {
                console.error(`[CARGOS] O cargo ${roleId} configurado não existe ou não está acessível no servidor ${guild.id}.`);
                continue;
              }
              roleObjects.set(roleId, role);
              if (role.position >= botMember.roles.highest.position) {
                console.error(`[CARGOS] O cargo "${role.name}" (${roleId}) está acima ou no mesmo nível do cargo mais alto do bot. Reordene os cargos no Discord.`);
              }
            }
            // Primeiro aplica o cargo de aprovado; depois remove os cargos configurados
            // em REMOVE_ROLE_ID. A remoção não é silenciosamente ignorada por uma
            // comparação local de posições: tentamos a operação e registramos o erro
            // real retornado pelo Discord, caso a hierarquia/permissão impeça a troca.
            if (/^\d{17,20}$/.test(cfg.approvedRoleId)) {
              const role = roleObjects.get(cfg.approvedRoleId);
              if (!role) {
                console.error('[CONFIG] APPROVED_ROLE_ID aponta para um cargo que não foi encontrado; cargo de aprovado não aplicado.');
              } else {
                try {
                  if (!freshMember.roles.cache.has(cfg.approvedRoleId)) {
                    await freshMember.roles.add(cfg.approvedRoleId, `Allowlist aprovada por ${interaction.user.id}`);
                  }
                  const refreshedAfterAdd = await guild.members.fetch({ user: app.user_id, force: true }).catch(() => null);
                  if (refreshedAfterAdd?.roles.cache.has(cfg.approvedRoleId)) {
                    console.log(`[CARGOS] Cargo de aprovado "${role.name}" (${cfg.approvedRoleId}) confirmado no usuário ${app.user_id}.`);
                  } else {
                    console.error(`[CARGOS] O Discord não confirmou o cargo de aprovado ${cfg.approvedRoleId} no usuário ${app.user_id}.`);
                  }
                } catch (e) {
                  console.error(`[CARGOS] Falha ao adicionar o cargo de aprovado ${cfg.approvedRoleId} ao usuário ${app.user_id}: ${e.message}`);
                }
              }
            } else {
              console.error('[CONFIG] APPROVED_ROLE_ID ausente ou inválido; cargo de aprovado não aplicado.');
            }

            // Rebusca o membro para trabalhar com o estado mais recente dos cargos.
            let memberForRemoval = await guild.members.fetch({ user: app.user_id, force: true }).catch(() => freshMember);
            for (const roleId of validRemoveRoleIds) {
              const role = roleObjects.get(roleId);
              if (!role) continue;
              if (!memberForRemoval.roles.cache.has(roleId)) {
                console.log(`[CARGOS] Usuário ${app.user_id} já não possui o cargo configurado para remoção "${role.name}" (${roleId}).`);
                continue;
              }
              try {
                await memberForRemoval.roles.remove(roleId, `Allowlist aprovada por ${interaction.user.id}`);
                memberForRemoval = await guild.members.fetch({ user: app.user_id, force: true }).catch(() => memberForRemoval);
                if (memberForRemoval.roles.cache.has(roleId)) {
                  console.error(`[CARGOS] A remoção do cargo "${role.name}" (${roleId}) foi solicitada, mas o cargo continua no usuário ${app.user_id}. Verifique hierarquia/permissões do bot.`);
                } else {
                  console.log(`[CARGOS] Cargo anterior "${role.name}" (${roleId}) removido e confirmado no usuário ${app.user_id}.`);
                }
              } catch (e) {
                console.error(`[CARGOS] Falha ao remover o cargo anterior "${role.name}" (${roleId}) do usuário ${app.user_id}: ${e.message}. Confira se o cargo do bot está acima desse cargo e se ele tem Gerenciar cargos.`);
              }
            }
          }
          // O ID fica no começo do apelido para nunca ser cortado pelo limite de 32 caracteres.
          const nickname = `${exclusiveId} | ${displayName}`.slice(0, 32);
          try {
            await freshMember.setNickname(nickname, `Allowlist aprovada por ${interaction.user.id}`);
            console.log(`[APROVACAO] ID ${exclusiveId} aplicado no apelido de ${app.user_id}: "${nickname}".`);
          } catch (e) {
            console.error(`[APROVACAO] ID ${exclusiveId} salvo, mas falha ao alterar apelido de ${app.user_id}:`, e.message);
          }
        }
      }
      const dmTitle = decision === 'approved' ? cfg.approvedDmTitle : cfg.rejectedDmTitle;
      const dmText = decision === 'approved' ? `${cfg.approvedDmText}\n\n**Seu ID da Allowlist: ${exclusiveId}**` : cfg.rejectedDmText;
      if (user) await user.send({ components:[container(dmTitle,dmText)], flags }).catch(()=>{});
      const announcement = (decision === 'approved' ? cfg.approvedAnnouncement : cfg.rejectedAnnouncement).replaceAll('{MENÇÃO}',`<@${app.user_id}>`).replaceAll('{ID}',exclusiveId ? String(exclusiveId) : '');
      try { const ch = await client.channels.fetch(cfg.resultsChannelId); await ch.send({ components:[container('Resultado da Allowlist',`${announcement}\n\n${decision === 'approved' ? 'Aprovada' : 'Reprovada'} • Candidato: <@${app.user_id}>${exclusiveId ? `\nID: **${exclusiveId}**` : ''}`)], flags, allowedMentions:{users:[app.user_id]} }); } catch(e) { console.error('Falha no anúncio:',e.message); }
      await log(guild, `Allowlist #${appId} ${decision === 'approved' ? 'APROVADA' : 'REPROVADA'} por <@${interaction.user.id}>. Candidato: <@${app.user_id}>. ${exclusiveId ? `ID atribuído: ${exclusiveId}.` : ''} DM enviada: tentativa realizada.`);
      return interaction.editReply({ components:[container('Decisão registrada',`Solicitação #${appId} marcada como **${decision === 'approved' ? 'aprovada' : 'reprovada'}**.${exclusiveId ? ` ID exclusivo: **${exclusiveId}**.` : ''}`)], flags });
    }
  } catch (error) {
    console.error('Erro na interação:',error.stack || error.message);
    const payload = { components:[container('Erro','Ocorreu um erro ao processar sua ação. Confira a configuração e os logs do bot.')], flags, ephemeral:true };
    if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(()=>{}); else await interaction.reply(payload).catch(()=>{});
  }
});

async function processCandidateMessage(message) {
  if (message.author.bot || !message.guild) return;
  const app = db.prepare("SELECT * FROM applications WHERE ticket_channel_id=? AND status IN ('awaiting_start','in_progress') LIMIT 1").get(message.channel.id);
  if (!app || message.author.id !== app.user_id) return;
  const content = message.content.trim();
  const answers = JSON.parse(app.answers_json || '[]');
  // O estado da aplicação, e não o índice 0, determina se aguardamos o 'Sim'.
  // Antes, após enviar a primeira pergunta, o registro continuava com índice 0
  // e respostas vazias; a primeira alternativa era confundida com a confirmação.
  if (app.status === 'awaiting_start') {
    if (content.toLowerCase() !== 'sim') return;
    setApp.run(app.ticket_channel_id, 'in_progress', 0, JSON.stringify([]), app.id);
    await message.reply({ components:[container('Questionário iniciado',`Você responderá ${questions.length} perguntas. Envie apenas **1**, **2**, **3** ou **4** para cada pergunta. Respostas inválidas não avançam.`)], flags });
    await sendQuestion(message.channel,0);
    return;
  }
  if (app.status !== 'in_progress') return;
  const expectedIndex = answers.length;
  if (app.question_index !== expectedIndex) {
    console.error(`Estado inconsistente na solicitação #${app.id}: índice=${app.question_index}, respostas=${expectedIndex}. Reconciliando pelo total de respostas.`);
  }
  if (expectedIndex >= questions.length) {
    if (app.status === 'in_progress') await finishApplication(app, message.channel);
    return;
  }
  if (!/^[1-4]$/.test(content)) {
    await message.reply({ components:[container('Resposta inválida','Responda somente com um número de **1 a 4**. Sua resposta não foi registrada.')], flags });
    return;
  }
  answers.push({choice:Number(content), at:now()});
  const next = answers.length;
  setApp.run(app.ticket_channel_id, 'in_progress', next, JSON.stringify(answers), app.id);
  if (next < questions.length) await sendQuestion(message.channel,next);
  else await finishApplication(byId.get(app.id),message.channel);
}

// Serializa mensagens por canal para impedir que duas respostas simultâneas
// leiam o mesmo estado e sobrescrevam respostas no SQLite.
const messageQueues = new Map();
client.on(Events.MessageCreate, message => {
  if (message.author.bot || !message.guild) return;
  const channelId = message.channel.id;
  const previous = messageQueues.get(channelId) || Promise.resolve();
  const current = previous
    .then(() => processCandidateMessage(message))
    .catch(error => console.error(`Erro ao processar mensagem no canal ${channelId}:`, error.stack || error.message))
    .finally(() => { if (messageQueues.get(channelId) === current) messageQueues.delete(channelId); });
  messageQueues.set(channelId, current);
});

client.on(Events.Error, e => console.error('Discord client error:',e.message));
process.on('unhandledRejection', e => console.error('Unhandled rejection:',e?.message || e));
client.on(Events.ShardResume, async () => { await applyConfiguredPresence(client); });
client.login(cfg.token);
