const Database = require('better-sqlite3');
const fs = require('node:fs');
const path = require('node:path');
const dir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dir, { recursive: true });
const db = new Database(path.join(dir, 'allowlist.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, guild_id TEXT NOT NULL,
 ticket_channel_id TEXT, review_message_id TEXT, status TEXT NOT NULL DEFAULT 'in_progress',
 question_index INTEGER NOT NULL DEFAULT 0, answers_json TEXT NOT NULL DEFAULT '[]',
 created_at TEXT NOT NULL, decided_at TEXT, decided_by TEXT, decision_reason TEXT, exclusive_id INTEGER,
 display_name TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_apps_user_status ON applications(user_id, status);
CREATE TABLE IF NOT EXISTS player_ids (
 exclusive_id INTEGER PRIMARY KEY, user_id TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
 assigned_at TEXT NOT NULL, application_id INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS invite_stats (
 inviter_id TEXT PRIMARY KEY,
 invite_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS invite_joins (
 guild_id TEXT NOT NULL,
 invited_user_id TEXT NOT NULL,
 inviter_id TEXT NOT NULL,
 invite_code TEXT,
 joined_at TEXT NOT NULL,
 PRIMARY KEY (guild_id, invited_user_id)
);
CREATE INDEX IF NOT EXISTS idx_invite_joins_inviter ON invite_joins(guild_id, inviter_id);
CREATE TABLE IF NOT EXISTS anti_raid_bans (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, user_id TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(guild_id,user_id)
);
CREATE TABLE IF NOT EXISTS decisions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, application_id INTEGER NOT NULL, user_id TEXT NOT NULL,
 decision TEXT NOT NULL, staff_id TEXT NOT NULL, created_at TEXT NOT NULL, exclusive_id INTEGER
);
`);
// A solicitação ativa é verificada na aplicação; o histórico é preservado nesta tabela.
module.exports = db;
