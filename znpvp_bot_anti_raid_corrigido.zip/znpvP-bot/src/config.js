require('dotenv').config();
const required = ['DISCORD_TOKEN','CLIENT_ID','GUILD_ID','PANEL_CHANNEL_ID','REVIEW_CHANNEL_ID','LOG_CHANNEL_ID','RESULTS_CHANNEL_ID','TICKET_CATEGORY_ID','APPROVED_ROLE_ID'];
for (const key of required) if (!process.env[key] || process.env[key].startsWith('ID_') || process.env[key] === 'COLOQUE_O_TOKEN_AQUI') throw new Error(`Configuração obrigatória ausente ou inválida no .env: ${key}`);
const csv = (s='') => String(s ?? '').split(',').map(x => x.trim()).filter(Boolean);
const parseColor = (value, fallback=0xFF0000) => { const raw=String(value ?? '').trim().replace(/^#|^0x/i,''); const parsed=/^[0-9a-f]{6}$/i.test(raw) ? Number.parseInt(raw,16) : NaN; return Number.isFinite(parsed) ? parsed : fallback; };
const unescape = (s, fallback='') => (s ?? fallback).replace(/\\n/g, '\n');
module.exports = {
 token: process.env.DISCORD_TOKEN, clientId: process.env.CLIENT_ID, guildId: process.env.GUILD_ID,
 panelChannelId: process.env.PANEL_CHANNEL_ID, reviewChannelId: process.env.REVIEW_CHANNEL_ID,
 logChannelId: process.env.LOG_CHANNEL_ID, resultsChannelId: process.env.RESULTS_CHANNEL_ID,
 inviteLogChannelId: (process.env.INVITES_CHANNEL_ID || '').trim(),
 antiRaidChannelId: (process.env.ANTI_RAID_CHANNEL_ID || '').trim(),
 ticketCategoryId: process.env.TICKET_CATEGORY_ID?.trim(), removeRoleIds: csv(process.env.REMOVE_ROLE_ID), approvedRoleId: (process.env.APPROVED_ROLE_ID || '').trim(),
 reviewerRoleIds: csv(process.env.REVIEWER_ROLE_IDS), adminUserIds: csv(process.env.ADMIN_USER_IDS), adminRoleIds: csv(process.env.ADMIN_ROLE_IDS),
 imageUrl: process.env.PANEL_IMAGE_URL || '',
 connectImageUrl: process.env.CONNECT_IMAGE_URL || '',
 connectButtonUrl: process.env.CONNECT_BUTTON_URL || '',
 connectCode: process.env.CONNECT_CODE || 'connect jogar.znpvp.gg', // Cor única para todos os containers do sistema (azul-arroxeado Discord).
 color: parseColor(process.env.CONTAINER_COLOR, 0xFF0000),
 panelTitle: process.env.PANEL_TITLE || 'Sistema de Allowlist ZNPvP', panelDescription: unescape(process.env.PANEL_DESCRIPTION, '📝 **Allowlist por Staff (Perguntas abertas)**\n\nClique abaixo para iniciar sua **Allowlist**. Você irá **responder a perguntas em texto**; a **staff** lerá suas respostas e decidirá entre **Aprovar ou Reprovar**.'),
 startText: process.env.START_BUTTON_TEXT || 'Iniciar Allowlist', startEmoji: process.env.START_BUTTON_EMOJI || '📝',
 welcomeTitle: process.env.TICKET_WELCOME_TITLE || 'Allowlist ZNPvP', welcomeDescription: unescape(process.env.TICKET_WELCOME_DESCRIPTION, '**Bem-vindo ao sistema de Allowlist da ZNPvP!**\n\nPara iniciar sua Allowlist, digite **Sim** ou **sim** no chat.\n\nApós iniciar, responda às perguntas selecionando o número correspondente, de **1 a 4**. Leia cada situação com atenção e escolha a alternativa que representa como você realmente agiria dentro da cidade.\n\nA equipe analisará suas respostas antes de liberar sua entrada.'),
 submissionTitle: process.env.SUBMISSION_TITLE || 'Allowlist enviada!', submissionDescription: unescape(process.env.SUBMISSION_DESCRIPTION, '**Sua Allowlist foi enviada para análise da staff da ZNPvP!**\n\nPedimos que aguarde o prazo de até **2 dias** para receber uma resposta. Você será notificado por mensagem privada assim que sua solicitação for aprovada ou reprovada.\n\nObrigado por participar da ZNPvP!'),
 approvedDmTitle: process.env.APPROVED_DM_TITLE || 'Parabéns! Você foi aprovado! 🎉', approvedDmText: unescape(process.env.APPROVED_DM_TEXT, '**Sua Allowlist da ZNPvP foi aprovada!**\n\nAgora falta concluir a liberação dentro do jogo.\n\nAbra um ticket na categoria de atendimento e selecione a opção **Solicitar Liberação em Game**. Informe seu ID da Allowlist e seu nick do Roblox para que a equipe possa concluir o processo.\n\nSeja bem-vindo à ZNPvP!'),
 rejectedDmTitle: process.env.REJECTED_DM_TITLE || 'Sua Allowlist foi reprovada', rejectedDmText: unescape(process.env.REJECTED_DM_TEXT, '**Infelizmente, sua Allowlist da ZNPvP não foi aprovada nesta tentativa.**\n\nNão desista! Continue estudando as regras da cidade e tente novamente quando estiver disponível para uma nova solicitação.\n\nAgradecemos seu interesse em fazer parte da ZNPvP!'),
 approvedAnnouncement: unescape(process.env.APPROVED_ANNOUNCEMENT, '🎉 {MENÇÃO} foi aprovado na Allowlist da ZNPvP!\n\nParabéns pela aprovação! Consulte as instruções para concluir sua liberação dentro do jogo.'),
 rejectedAnnouncement: unescape(process.env.REJECTED_ANNOUNCEMENT, '❌ {MENÇÃO} foi reprovado na Allowlist da ZNPvP.'),
 idStart: Number(process.env.ID_START || 1238), idInitialMax: Number(process.env.ID_INITIAL_MAX || 8000), idHardMax: Number(process.env.ID_HARD_MAX || 30000)
};
