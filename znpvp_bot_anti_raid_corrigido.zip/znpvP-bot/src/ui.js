const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, MediaGalleryBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { color } = require('./config');
const flags = MessageFlags.IsComponentsV2;
function container(title, body, accent=color) {
  const c = new ContainerBuilder().setAccentColor(Number.isFinite(accent) ? accent : color);
  if (title) c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${title}`));
  if (title && body) c.addSeparatorComponents(new SeparatorBuilder());
  if (body) c.addTextDisplayComponents(new TextDisplayBuilder().setContent(body));
  return c;
}
function panelContainer(cfg) {
  const c = new ContainerBuilder().setAccentColor(color);
  if (cfg.imageUrl && /^https?:\/\//i.test(cfg.imageUrl)) c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems({ media: { url: cfg.imageUrl } }));
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${cfg.panelTitle}`));
  c.addSeparatorComponents(new SeparatorBuilder());
  c.addSectionComponents(section => section
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(cfg.panelDescription))
    .setButtonAccessory(new ButtonBuilder()
      .setCustomId('allowlist:start')
      .setStyle(ButtonStyle.Secondary)
      .setLabel(cfg.startText)
      .setEmoji(cfg.startEmoji || '📝')
    )
  );
  return c;
}
function questionContainer(index, item, accent=color) {
  const answers = item.a.map((a,i) => `**${i+1}.** ${a}`).join('\n\n');
  return container(`Pergunta ${index+1}`, `${item.q}\n\n${answers}`, accent);
}
function reviewContainer(app, questions, decision=null) {
  const heading = `**Candidato:** ${app.display_name}\n**Menção:** <@${app.user_id}>\n**Discord ID:** \`${app.user_id}\`\n**ID Allowlist:** ${app.exclusive_id ?? 'Ainda não atribuído'}\n**Solicitação:** ${app.id}\n**Data:** ${new Date(app.created_at).toLocaleString('pt-BR')}\n**Status:** ${decision || app.status}`;
  const c = container('Análise de Allowlist — ZNPvP', heading);
  if (!decision) c.addActionRowComponents(row => row.addComponents(
    new ButtonBuilder().setCustomId(`allowlist:approve:${app.id}`).setLabel('Aprovar').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`allowlist:reject:${app.id}`).setLabel('Reprovar').setStyle(ButtonStyle.Danger)
  ));
  else { c.addSeparatorComponents(new SeparatorBuilder()); c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`**Decisão:** ${decision}`)); }
  return c;
}
function reviewDetailContainers(app, questions) {
  const answers = JSON.parse(app.answers_json || '[]');
  const messages = [];
  for (let start=0; start<questions.length; start+=2) {
    const c = container(`Respostas do candidato — ${start+1} a ${Math.min(start+2,questions.length)}`, `Solicitação #${app.id} • <@${app.user_id}>`);
    for (let i=start;i<Math.min(start+2,questions.length);i++) {
      const q=questions[i], answer=answers[i];
      const content = `**${i+1}. ${q.q}**\n${q.a.map((a,j)=>`${j+1}. ${a}`).join('\n')}\n**Resposta escolhida:** ${answer ? `${answer.choice}. ${q.a[answer.choice-1]}` : 'Sem resposta registrada'}`;
      c.addSeparatorComponents(new SeparatorBuilder());
      c.addTextDisplayComponents(new TextDisplayBuilder().setContent(content.slice(0,3900)));
    }
    messages.push(c);
  }
  return messages;
}
function connectContainer(cfg) {
  const c = new ContainerBuilder().setAccentColor(color);
  if (cfg.connectImageUrl && /^https?:\/\//i.test(cfg.connectImageUrl)) {
    c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems({ media: { url: cfg.connectImageUrl } }));
  }
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent('# CONECTAR NO SERVIDOR ZNPvP'));
  c.addSeparatorComponents(new SeparatorBuilder());
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent('♙ **ZNPvP** está On nesse exato momento.'));
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent('♙ Copie o código abaixo e coloque no código do servidor do EH.'));
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent('```' + (cfg.connectCode || 'connect jogar.znpvp.gg') + '```'));
  c.addSeparatorComponents(new SeparatorBuilder());
  if (cfg.connectButtonUrl && /^https?:\/\//i.test(cfg.connectButtonUrl)) {
    c.addActionRowComponents(row => row.addComponents(
      new ButtonBuilder().setLabel('ENTRAR ZNPvP').setStyle(ButtonStyle.Link).setURL(cfg.connectButtonUrl)
    ));
  }
  return c;
}
module.exports = { container, panelContainer, connectContainer, questionContainer, reviewContainer, reviewDetailContainers, flags };
